package bemajava;

public class BemaString {
    public String buffer;
	
	public BemaString()
	{
		buffer = "";
	
	}
	public String getBuffer(){
		return buffer;
	}
}
